package se.tactical;

import static org.junit.Assert.*;

import org.junit.Test;

public class TacticalTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
