X-COM: Friends Known
==========================

Gets Friend names from Facebook, then will populate the random soldier name list with friends' names (from appropriate countries).

Still in alpha stages!

Info: http://james-firth.github.com/XCOM_Facebook_Friend_Squad/