# textcom
A Text-Based Roguelike in Python, based on XCOM: Enemy Unknown


**Running the game:**


Please have Python 3.x installed (where x is any number, just make sure it's 3.something, preferably 3.4.3). You can find a download at www.python.org/downloads Either double click on the program to run it in Terminal/IDLE/Command Prompt, or right click and go Open With...IDLE Shell.


If you already have it installed but aren't sure what version it is, just run IDLE if you can, and it should tell you. If you don't have Python 3.x, please upgrade to it, because the game won't run as well and might crash.


**How to play:**


On your turn, a list of takeable actions will be shown. Enter the number of the action you wish to take. It's that simple.
As you kill more aliens, you can level up your soldier, gaining loot and bonus stats, to help you kill more aliens faster. Every 5 rooms there will be an upgrade shop, where you can buy new weapons and augment your soldier.


**Next steps:**


Perks. More weapons. Weapon upgrades.


**Thanks to:**


Everyone who forked this and submitted bug reports! Big thanks to /u/net_goblin, who, without the help of, the game would not be as optimised as it is.

-/u/TachyonNZ
