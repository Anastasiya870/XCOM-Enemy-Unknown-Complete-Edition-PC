package se.tactical.input;

import static org.junit.Assert.fail;

import org.junit.Test;

public class InputControllerTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
