package se.tactical.systems;

import static org.junit.Assert.*;

import org.junit.Test;

public class RenderSystemTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
