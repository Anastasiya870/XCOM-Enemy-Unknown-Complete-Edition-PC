package se.tactical.systems;

import static org.junit.Assert.fail;

import org.junit.Test;

public class PlayerControlSystemTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
